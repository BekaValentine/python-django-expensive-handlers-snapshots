from django.db import models
from django.conf.urls import url
from django.urls import path


class MyModel(models.Model):
  pass

# this is a handler according to `patterns` below
def cheap_handler():
  pass

# this is also a handler
def expensive_handler_save():
  MyModel().save()

# this is NOT a handler according to `patterns`
def expensive_handler_delete():
  MyModel().delete()

# this is a handler
def expensive_handler_update():
  MyModel().update()

# this is a handler
def expensive_handler_create():
  MyModel.objects.create()

# this is a handler
def expensive_handler_create_indirect():
  helper()

# this is NOT a handler but is used by one
def helper():
  MyModel.objects.create()

patterns = [
  url("cheap_handler", cheap_handler),
  url("expensive_handler_save", expensive_handler_save),
  url("expensive_handler_update", expensive_handler_update),
  url("expensive_handler_create", expensive_handler_create),
  url("expensive_handler_create_indirect", expensive_handler_create_indirect),
]
