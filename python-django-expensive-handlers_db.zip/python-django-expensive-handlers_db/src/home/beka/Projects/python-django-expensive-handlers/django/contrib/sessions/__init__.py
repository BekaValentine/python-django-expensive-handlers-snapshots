default_app_config ꞊ 'django.contrib.sessions.apps.SessionsConfig'
