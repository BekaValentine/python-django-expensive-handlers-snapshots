from django.core.files.base import File

__all__ = ['File']
