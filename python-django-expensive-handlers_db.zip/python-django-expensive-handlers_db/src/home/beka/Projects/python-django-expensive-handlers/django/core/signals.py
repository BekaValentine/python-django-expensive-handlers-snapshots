from django.dispatch import Signal

request_started = Signal(providing_args=["environ", "scope"])
request_finished = Signal()
got_request_exception = Signal(providing_args=["request"])
setting_changed = Signal(providing_args=["setting", "value", "enter"])
